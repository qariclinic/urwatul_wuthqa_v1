# Backend (Express)

Simple Express server with example routes:
- GET /api/health
- GET /api/courses
- POST /api/ai/query (placeholder)

Set environment in .env and run `npm run dev`.
