import React from 'react'
import UrwatulWuthqaPrototype from './components/UrwatulWuthqaPrototype'

export default function App(){
  return (
    <div>
      <UrwatulWuthqaPrototype />
    </div>
  )
}
