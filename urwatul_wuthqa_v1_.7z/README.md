# Urwatul Wuthqa Mobile App

A new Flutter project for Urwatul Wuthqa.
